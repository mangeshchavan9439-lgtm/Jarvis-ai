# JARVIS Full Assistant — OPPO Android 16 (Project v3.0)

## इसमें क्या है
- हिंदी Speech-to-Text और Text-to-Speech
- टाइप और voice दोनों से कमांड
- YouTube, WhatsApp, Instagram, Facebook, Chrome लॉन्च
- टॉर्च और मीडिया वॉल्यूम नियंत्रण
- Wi-Fi, Bluetooth, Display और सामान्य Settings पेज
- Accessibility अनुमति मिलने पर Home, Back, Recent Apps, Notifications, Quick Settings
- अलार्म सेट करने की पुष्टि वाली सिस्टम स्क्रीन
- कॉल के लिए Dialer; SMS के लिए Messaging app
- Google Maps navigation/search, Google web search, तारीख और समय
- OpenAI-compatible HTTPS chat-completions endpoint से वैकल्पिक AI Brain

## Build करके APK बनाएँ
1. ZIP को Windows/Mac/Linux कंप्यूटर पर Extract करें।
2. Android Studio का हाल का stable version और JDK 17 इंस्टॉल करें।
3. Android Studio में `JarvisFull` folder खोलें।
4. Android SDK Platform 36 इंस्टॉल करें और Gradle Sync पूरा होने दें।
5. OPPO फोन में Developer options > USB debugging चालू करें; USB से जोड़कर Run करें।
6. APK बनाने के लिए Build > Build APK(s) चुनें। APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।
7. फोन में ऐप खोलें और Microphone permission दें।

## Accessibility कंट्रोल चालू करना
1. ऐप में "Accessibility Settings खोलें" दबाएँ।
2. Android Accessibility settings में Jarvis सेवा खोजें।
3. विवरण पढ़कर केवल तभी Enable करें जब आप इस सिस्टम-स्तरीय अनुमति से सहमत हों।
4. वापस Jarvis में आएँ। Home / Back / Recent / Notifications / Quick Settings commands आज़माएँ।
यह सेवा केवल Android के documented global navigation actions करती है; यह हर ऐप में मनमाने taps या निजी सामग्री पढ़ने का दावा नहीं करती।

## AI Brain कॉन्फ़िगरेशन
- HTTPS endpoint में अपने provider का OpenAI-compatible `/v1/chat/completions` endpoint डालें।
- Model field में provider द्वारा दिया गया model name डालें।
- API key केवल तभी दें जब आपका endpoint Bearer token स्वीकार करता हो।
- API key इस ऐप द्वारा disk पर सेव नहीं की जाती; फिर भी production में सीधे mobile app से provider key भेजने के बजाय अपना secure backend/proxy उपयोग करें।
- गलत endpoint, model या key पर AI काम नहीं करेगा। नेटवर्क जरूरी है।

## Wake Word / "Hey Jarvis"
इस project में always-on wake-word engine शामिल नहीं है। Android 16 पर विश्वसनीय wake word के लिए अलग wake-word SDK (उदाहरणार्थ Picovoice Porcupine), उसकी लाइसेंस/AccessKey, microphone foreground service, persistent notification, battery optimization handling और privacy controls चाहिए। इसे बिना SDK key और device पर परीक्षण के चालू बताना सही नहीं होगा। फिलहाल ऐप foreground में mic button दबाने पर सुनता है।

## सुरक्षा और सीमाएँ
- ऐप खुद से कॉल या SMS नहीं भेजता; Dialer/Messaging UI खोलता है ताकि आप पुष्टि कर सकें।
- ऐप लॉक/अनलॉक, OTP पढ़ना, WhatsApp में संदेश भेजना या सभी ऐप्स में arbitrary touch automation नहीं करता।
- Android/Oppo की अनुमति और OS restrictions के बिना फोन पर पूर्ण नियंत्रण संभव नहीं।
- यह source project है, prebuilt APK नहीं। Android Studio से build करना आवश्यक है।
- ऐप में कोई API key या password hard-code न करें।
