package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlarmClock
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var commandInput: EditText
    private lateinit var endpointInput: EditText
    private lateinit var apiKeyInput: EditText
    private lateinit var modelInput: EditText
    private var pendingTorch: Boolean? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(listener)
        } else status.text = "इस फोन पर Speech Recognition उपलब्ध नहीं है।"
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 20)
            setBackgroundColor(0xFF071426.toInt())
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        body.addView(TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 36f
            gravity = Gravity.CENTER
            setTextColor(0xFF42C8FF.toInt())
        }, lp())
        body.addView(TextView(this).apply {
            text = "FULL ASSISTANT • OPPO / ANDROID"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xFF9AB7D2.toInt())
        }, lp())
        status = TextView(this).apply {
            text = "नमस्ते! मैं Jarvis हूँ।"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(-1)
            setPadding(0, 24, 0, 10)
        }
        transcript = TextView(this).apply {
            text = "आवाज़ या टेक्स्ट से कमांड दें"
            gravity = Gravity.CENTER
            setTextColor(0xFFB8D5EA.toInt())
        }
        body.addView(status, lp())
        body.addView(transcript, lp())
        body.addView(Button(this).apply {
            text = "🎙 बोलकर कमांड दें"
            textSize = 17f
            setOnClickListener { startListening() }
        }, lp())
        commandInput = EditText(this).apply { hint = "कमांड लिखें..." }
        body.addView(commandInput, lp())
        body.addView(Button(this).apply {
            text = "कमांड चलाएँ"
            setOnClickListener { handleCommand(commandInput.text.toString()) }
        }, lp())

        body.addView(section("फोन कंट्रोल अनुमति"))
        body.addView(TextView(this).apply {
            text = "Home / Back / Recent Apps / Notifications जैसे सिस्टम नेविगेशन के लिए Accessibility अनुमति वैकल्पिक है। इसे चालू करने पर Android सेटिंग्स में Jarvis को स्वयं Enable करें।"
            textSize = 12f
            setTextColor(0xFFB8D5EA.toInt())
        }, lp())
        body.addView(Button(this).apply {
            text = "Accessibility Settings खोलें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, lp())

        body.addView(section("AI Brain – वैकल्पिक API"))
        body.addView(TextView(this).apply {
            text = "अपने सुरक्षित OpenAI-compatible HTTPS API endpoint और model की जानकारी दें। API key केवल इस स्क्रीन की मेमोरी में रहेगी; ऐप उसे सेव नहीं करता। APK में key hard-code न करें।"
            textSize = 12f
            setTextColor(0xFFB8D5EA.toInt())
        }, lp())
        endpointInput = EditText(this).apply { hint = "HTTPS API URL (उदा. https://your-server/v1/chat/completions)" }
        modelInput = EditText(this).apply { hint = "Model name (उदा. आपके provider का model)" }
        apiKeyInput = EditText(this).apply {
            hint = "API key (वैकल्पिक)"
            inputType = 0x00000081
        }
        body.addView(endpointInput, lp())
        body.addView(modelInput, lp())
        body.addView(apiKeyInput, lp())
        body.addView(Button(this).apply {
            text = "AI से पूछें"
            setOnClickListener {
                val prompt = commandInput.text.toString().trim()
                if (prompt.isBlank()) say("पहले सवाल लिखें।")
                else askAi(prompt)
            }
        }, lp())

        body.addView(section("त्वरित कमांड"))
        listOf(
            "YouTube खोलो", "WhatsApp खोलो", "Instagram खोलो", "Chrome खोलो",
            "टॉर्च चालू करो", "टॉर्च बंद करो", "आवाज़ बढ़ाओ", "आवाज़ कम करो",
            "Home", "Back", "Recent Apps", "Notifications", "Quick Settings",
            "Wi-Fi सेटिंग खोलो", "Bluetooth सेटिंग खोलो", "Display सेटिंग खोलो",
            "कैमरा खोलो", "अलार्म लगाओ 7 बजे", "समय बताओ", "तारीख बताओ",
            "मौसम खोजो"
        ).forEach { cmd ->
            body.addView(Button(this).apply {
                text = cmd
                setOnClickListener { handleCommand(cmd) }
            }, lp())
        }
        body.addView(TextView(this).apply {
            text = "सीमाएँ: यह build लगातार background में 'Hey Jarvis' नहीं सुनता। Wake word के लिए अलग licensed wake-word engine और foreground microphone service की जरूरत होगी। Android सुरक्षा के कारण हर ऐप में मनमाने taps/संदेश भेजना/कॉल करना उपलब्ध नहीं है।"
            textSize = 12f
            setTextColor(0xFF91A9BD.toInt())
            setPadding(0, 20, 0, 12)
        }, lp())
        val scroll = ScrollView(this).apply { addView(body) }
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
    }

    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 }
    private fun section(label: String) = TextView(this).apply {
        text = label
        textSize = 17f
        setTextColor(0xFF42C8FF.toInt())
        setPadding(0, 22, 0, 8)
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        val r = recognizer ?: run { say("Speech Recognition उपलब्ध नहीं है।"); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Jarvis को कमांड दें")
        }
        status.text = "सुन रहा हूँ..."
        r.startListening(intent)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { status.text = "सुन रहा हूँ..." }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { status.text = "कमांड समझ रहा हूँ..." }
        override fun onError(error: Int) { status.text = "आवाज़ समझ नहीं आई। दोबारा कोशिश करें।" }
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            transcript.text = "आपने कहा: $text"
            handleCommand(text)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale.ROOT).trim()
        if (c.isBlank()) { say("कमांड खाली है।"); return }
        transcript.text = "कमांड: $raw"
        try {
            when {
                has(c, "टॉर्च", "torch", "flashlight") && has(c, "चालू", "on") -> toggleTorch(true)
                has(c, "टॉर्च", "torch", "flashlight") && has(c, "बंद", "off") -> toggleTorch(false)
                has(c, "youtube", "यूट्यूब") -> launch("com.google.android.youtube", "YouTube")
                has(c, "whatsapp", "व्हाट्सएप") -> launch("com.whatsapp", "WhatsApp")
                has(c, "instagram", "इंस्टाग्राम") -> launch("com.instagram.android", "Instagram")
                has(c, "facebook", "फेसबुक") -> launch("com.facebook.katana", "Facebook")
                has(c, "chrome", "क्रोम") -> launch("com.android.chrome", "Chrome")
                has(c, "कैमरा", "camera") -> startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                has(c, "wifi", "वाईफाई") -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                has(c, "bluetooth", "ब्लूटूथ") -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                has(c, "display", "डिस्प्ले", "स्क्रीन सेटिंग") -> startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
                has(c, "सेटिंग", "settings") -> startActivity(Intent(Settings.ACTION_SETTINGS))
                has(c, "आवाज बढ़", "वॉल्यूम बढ़", "volume up") -> volume(AudioManager.ADJUST_RAISE)
                has(c, "आवाज कम", "वॉल्यूम कम", "volume down") -> volume(AudioManager.ADJUST_LOWER)
                has(c, "home", "होम स्क्रीन") -> global("home")
                has(c, "back", "वापस") -> global("back")
                has(c, "recent", "हाल के ऐप") -> global("recents")
                has(c, "notification", "नोटिफिकेशन") -> global("notifications")
                has(c, "quick settings", "क्विक सेटिंग") -> global("quicksettings")
                has(c, "अलार्म", "alarm") -> alarm(raw)
                has(c, "कॉल", "call") -> dial(raw)
                has(c, "मैसेज", "sms") -> smsDraft(raw)
                has(c, "मैप", "रास्ता", "navigate") -> maps(raw)
                has(c, "समय", "time") -> say("अभी समय है " + SimpleDateFormat("hh:mm a", Locale("hi", "IN")).format(Date()))
                has(c, "तारीख", "date") -> say("आज " + SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("hi", "IN")).format(Date()) + " है।")
                has(c, "मौसम", "weather") -> webSearch("आज का मौसम")
                has(c, "खोजो", "search", "गूगल") -> webSearch(raw.replace("गूगल", "").replace("खोजो", "").replace("search", "").trim())
                has(c, "मदद", "help") -> say("मैं ऐप खोल सकता हूँ, टॉर्च, वॉल्यूम और सिस्टम नेविगेशन नियंत्रित कर सकता हूँ। AI के लिए AI Brain सेक्शन में endpoint सेट करें।")
                else -> say("यह कमांड नहीं पहचान पाया। AI Brain में सवाल पूछें या मदद बोलें।")
            }
        } catch (_: Exception) { say("यह काम इस डिवाइस पर पूरा नहीं हो पाया।") }
    }

    private fun has(s: String, vararg words: String) = words.any { s.contains(it) }

    private fun launch(pkg: String, label: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) say("$label इंस्टॉल नहीं है।") else { startActivity(i); say("$label खोल रहा हूँ।") }
    }

    private fun toggleTorch(on: Boolean) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingTorch = on
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 11)
            return
        }
        val manager = getSystemService(CAMERA_SERVICE) as CameraManager
        val id = manager.cameraIdList.firstOrNull {
            manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: run { say("फ्लैश उपलब्ध नहीं है।"); return }
        manager.setTorchMode(id, on)
        say(if (on) "टॉर्च चालू।" else "टॉर्च बंद।")
    }

    private fun volume(direction: Int) {
        (getSystemService(AUDIO_SERVICE) as AudioManager)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        say("वॉल्यूम बदल दिया।")
    }

    private fun global(action: String) {
        val service = JarvisAccessibilityService.instance
        if (service == null) {
            say("पहले Accessibility Settings में Jarvis सेवा Enable करें।")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } else {
            val ok = service.performJarvisAction(action)
            say(if (ok) "कमांड पूरी।" else "यह सिस्टम कमांड उपलब्ध नहीं है।")
        }
    }

    private fun alarm(raw: String) {
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(raw)
        if (m == null) {
            startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            say("अलार्म ऐप खोल रहा हूँ।")
            return
        }
        val h = m.groupValues[1].toIntOrNull() ?: 7
        val min = m.groupValues[2].toIntOrNull() ?: 0
        if (h !in 0..23 || min !in 0..59) { say("समय सही नहीं है।"); return }
        startActivity(Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, h)
            putExtra(AlarmClock.EXTRA_MINUTES, min)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        })
        say("अलार्म की पुष्टि वाली स्क्रीन खोल रहा हूँ।")
    }

    private fun dial(raw: String) {
        val number = Regex("[+]?[0-9][0-9 -]{5,}").find(raw)?.value?.replace(" ", "")?.replace("-", "")
        startActivity(Intent(Intent.ACTION_DIAL).apply { if (number != null) data = Uri.parse("tel:$number") })
        say("डायलर खोल रहा हूँ। कॉल करने से पहले नंबर जाँचें।")
    }

    private fun smsDraft(raw: String) {
        val number = Regex("[+]?[0-9][0-9 -]{5,}").find(raw)?.value?.replace(" ", "")?.replace("-", "")
        startActivity(Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${number ?: ""}")
            putExtra("sms_body", "")
        })
        say("SMS ऐप खोल रहा हूँ। भेजने से पहले संदेश जाँचें।")
    }

    private fun maps(raw: String) {
        val dest = raw.replace("मैप", "").replace("रास्ता", "").replace("बताओ", "").replace("जाओ", "").trim()
        val uri = Uri.parse("google.navigation:q=" + Uri.encode(dest.ifBlank { "nearby places" }))
        val i = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps")
        if (i.resolveActivity(packageManager) != null) startActivity(i)
        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(dest))))
        say("मैप खोल रहा हूँ।")
    }

    private fun webSearch(q: String) {
        val query = q.ifBlank { "Google" }
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))))
        say("खोज रहा हूँ।")
    }

    private fun askAi(prompt: String) {
        val endpoint = endpointInput.text.toString().trim()
        val model = modelInput.text.toString().trim()
        val key = apiKeyInput.text.toString().trim()
        if (!endpoint.startsWith("https://") || model.isBlank()) {
            say("AI के लिए HTTPS endpoint और model name भरें।")
            return
        }
        status.text = "AI से जवाब ला रहा हूँ..."
        thread {
            var result = "AI सर्वर से संपर्क नहीं हो पाया। Endpoint और इंटरनेट जाँचें।"
            try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    if (key.isNotBlank()) setRequestProperty("Authorization", "Bearer $key")
                }
                val body = JSONObject().apply {
                    put("model", model)
                    put("messages", JSONArray().put(JSONObject().apply {
                        put("role", "system")
                        put("content", "You are Jarvis, a helpful Hindi-speaking mobile assistant. Reply concisely in Hindi. Do not claim to perform phone actions.")
                    }).put(JSONObject().apply {
                        put("role", "user")
                        put("content", prompt)
                    }))
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                result = json.optJSONArray("choices")?.optJSONObject(0)
                    ?.optJSONObject("message")?.optString("content")
                    ?.takeIf { it.isNotBlank() }
                    ?: "AI response नहीं मिला: HTTP ${conn.responseCode}"
                conn.disconnect()
            } catch (e: Exception) {
                result = "AI कनेक्शन में समस्या: ${e.localizedMessage ?: "unknown error"}"
            }
            runOnUiThread { say(result) }
        }
    }

    private fun say(message: String) {
        status.text = message
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
    }

    override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, grants: IntArray) {
        super.onRequestPermissionsResult(code, permissions, grants)
        if (grants.isNotEmpty() && grants[0] == PackageManager.PERMISSION_GRANTED) {
            when (code) {
                10 -> startListening()
                11 -> pendingTorch?.let { val value = it; pendingTorch = null; toggleTorch(value) }
            }
        } else say("अनुमति नहीं मिली।")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
